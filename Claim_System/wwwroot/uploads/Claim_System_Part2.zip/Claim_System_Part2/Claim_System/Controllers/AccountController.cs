using Microsoft.AspNetCore.Mvc;
using Claim_System.Models;
using Microsoft.AspNetCore.Http;
using System.Collections.Generic;
using System.Linq;

namespace Claim_System.Controllers
{
    public class AccountController : Controller
    {
        // Simple in-memory users for demo
        private static List<User> users = new List<User>
        {
            new User { Username = "lecturer", Password = "123", Role = "Lecturer" },
            new User { Username = "coordinator", Password = "123", Role = "Coordinator" }
        };

        [HttpGet]
        public IActionResult Login()
        {
            return View();
        }

        [HttpPost]
        public IActionResult Login(string username, string password)
        {
            var user = users.FirstOrDefault(u => u.Username == username && u.Password == password);
            if (user != null)
            {
                HttpContext.Session.SetString("Role", user.Role);
                HttpContext.Session.SetString("User", user.Username);
                if (user.Role == "Lecturer")
                    return RedirectToAction("Index", "Claims");
                return RedirectToAction("Manage", "Claims");
            }

            ViewBag.Error = "Invalid username or password.";
            return View();
        }

        public IActionResult Logout()
        {
            HttpContext.Session.Clear();
            return RedirectToAction("Login");
        }
    }
}
