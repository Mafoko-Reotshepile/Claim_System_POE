using Microsoft.AspNetCore.Mvc;
using Claim_System.Models;
using Microsoft.AspNetCore.Http;
using System.Collections.Generic;
using System.Linq;
using System.IO;
using System;

namespace Claim_System.Controllers
{
    public class ClaimsController : Controller
    {
        private static List<Claim> _claims = new List<Claim>();

        [HttpGet]
        public IActionResult Index()
        {
            var role = HttpContext.Session.GetString("Role");
            if (role != "Lecturer") return RedirectToAction("Login", "Account");

            var username = HttpContext.Session.GetString("User");
            var lecturerClaims = _claims.Where(c => c.LecturerName == username).ToList();
            return View(lecturerClaims);
        }

        [HttpGet]
        public IActionResult Create()
        {
            var role = HttpContext.Session.GetString("Role");
            if (role != "Lecturer") return RedirectToAction("Login", "Account");
            return View();
        }

        [HttpPost]
        public IActionResult Create(Claim claim, Microsoft.AspNetCore.Http.IFormFile? file)
        {
            if (!ModelState.IsValid)
                return View(claim);

            // Save file if provided
            if (file != null && file.Length > 0)
            {
                var uploadsPath = Path.Combine(Directory.GetCurrentDirectory(), "wwwroot", "uploads");
                if (!Directory.Exists(uploadsPath))
                    Directory.CreateDirectory(uploadsPath);

                var safeFileName = Path.GetFileName(file.FileName);
                var filePath = Path.Combine(uploadsPath, safeFileName);

                using (var stream = new FileStream(filePath, FileMode.Create))
                {
                    file.CopyTo(stream);
                }

                claim.FileName = safeFileName;
            }

            claim.Id = _claims.Count + 1;
            claim.LecturerName = HttpContext.Session.GetString("User") ?? "Unknown";
            _claims.Add(claim);
            return RedirectToAction("Index");
        }

        [HttpGet]
        public IActionResult Manage()
        {
            var role = HttpContext.Session.GetString("Role");
            if (role != "Coordinator") return RedirectToAction("Login", "Account");
            return View(_claims);
        }

        [HttpPost]
        public IActionResult Approve(int id)
        {
            var claim = _claims.FirstOrDefault(c => c.Id == id);
            if (claim != null) claim.Status = "Approved";
            return RedirectToAction("Manage");
        }

        [HttpPost]
        public IActionResult Reject(int id)
        {
            var claim = _claims.FirstOrDefault(c => c.Id == id);
            if (claim != null) claim.Status = "Rejected";
            return RedirectToAction("Manage");
        }
    }
}
