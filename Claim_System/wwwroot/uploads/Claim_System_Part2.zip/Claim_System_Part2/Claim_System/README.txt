Claim_System - ASP.NET Core MVC (net8.0) - In-memory prototype
Contents:
- Claim_System/ (web app)
  - Controllers/, Models/, Views/, wwwroot/
- Claim_System.Tests/ (xUnit tests)

Default test users:
- Lecturer: username=lecturer password=123
- Coordinator: username=coordinator password=123

How to run:
1. Extract the ZIP to a folder.
2. Open the Claim_System.sln in Visual Studio 2022/2023 or open the Claim_System project file.
3. Make sure you have .NET 8 SDK installed.
4. Build the solution and run (F5). The app will open on https://localhost:xxxx
5. Login as 'lecturer' to submit claims, or 'coordinator' to manage claims.
6. Uploaded files are stored in wwwroot/uploads and are accessible via the app (for demo purposes).

Notes:
- Data is stored in-memory; restarting the app will clear claims.
- Unit tests are included in Claim_System.Tests project. Run them from Test Explorer.
